var m=Object.defineProperty;var v=(c,i,t)=>i in c?m(c,i,{enumerable:!0,configurable:!0,writable:!0,value:t}):c[i]=t;var u=(c,i,t)=>v(c,typeof i!="symbol"?i+"":i,t);import{g as y,s as f,i as b,d as x}from"./students-repo-DiS-lCzz.js";import{getTemporaryPhotos as k}from"./temp-photos-BVCntkeW.js";import{getCarnet as w}from"./repo-C_U3TJ5T.js";import{D as S}from"./skills-CFwbsuGQ.js";import{router as h}from"./router-CANAWL_W.js";import"./student-modal-CsP6WSdO.js";import"./db-BumgrVF8.js";import"./main-CA8ihvBi.js";function C(c=".json"){return new Promise(i=>{const t=document.createElement("input");t.type="file",t.accept=c,t.onchange=e=>{const s=e.target.files?.[0];i(s||null)},t.oncancel=()=>i(null),t.click()})}class $ extends HTMLElement{constructor(){super();u(this,"students",[]);u(this,"filteredStudents",[]);u(this,"searchQuery","");u(this,"sortBy","nom");u(this,"studentsProgression",new Map);u(this,"studentsSkillsCount",new Map);this.loadStudents()}connectedCallback(){this.render()}async loadStudents(){try{this.students=await y(),await this.applyFilters(),this.render()}catch(t){console.error("Erreur lors du chargement des élèves:",t),this.innerHTML=`
        <div class="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
          <div class="max-w-md mx-auto text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
              Impossible de charger la liste des élèves
            </h2>
            <p class="text-gray-600 dark:text-gray-400 mb-4">
              Vérifiez vos données locales et réessayez.
            </p>
            <button class="btn-primary" onclick="location.reload()">Réessayer</button>
          </div>
        </div>
      `}}async updateTempPhotosCount(){try{const t=await k(),e=this.querySelector("#temp-photos-count");e&&(e.textContent=t.length.toString(),e.classList.toggle("hidden",t.length===0))}catch(t){console.error("Erreur lors du comptage des photos temporaires:",t)}}async refreshPhotosCount(){await this.updateTempPhotosCount()}async applyFilters(){const t=this.searchQuery.trim().toLowerCase();this.studentsProgression.clear(),this.studentsSkillsCount.clear();const e=t?this.students.filter(s=>{const r=s.nom.toLowerCase(),o=s.prenom.toLowerCase();return r.includes(t)||o.includes(t)||`${o} ${r}`.includes(t)}):[...this.students];if(this.sortBy==="progression"){this.filteredStudents=await this.sortByProgression(e);return}await this.calculateStudentsStats(e),this.filteredStudents=f(e,this.sortBy)}async calculateStudentProgression(t){const e=await w(t.id);let s=0,r=0,o=0;if(e)for(const n of S)for(const d of n.skills){s++;const l=e.skills[d.id];if(l&&l.status!=="")switch(r++,l.status){case"A":o+=100;break;case"EC":o+=50;break;case"NA":default:o+=0;break}}return{progression:r>0?o/r:0,evaluated:r,total:s}}async calculateStudentsStats(t){await Promise.all(t.map(async e=>{const{progression:s,evaluated:r,total:o}=await this.calculateStudentProgression(e);this.studentsProgression.set(e.id,s),this.studentsSkillsCount.set(e.id,{evaluated:r,total:o})}))}async sortByProgression(t){const e=await Promise.all(t.map(async s=>{const{progression:r,evaluated:o,total:a}=await this.calculateStudentProgression(s);return this.studentsProgression.set(s.id,r),this.studentsSkillsCount.set(s.id,{evaluated:o,total:a}),{student:s,progression:r}}));return e.sort((s,r)=>r.progression-s.progression),e.map(s=>s.student)}render(){this.innerHTML=`
      <div class="min-h-screen bg-gray-50 dark:bg-gray-900">
        <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 pt-safe-top">
          <div class="px-4 py-4">
            <div class="flex items-center justify-between">
              <button id="back-home-btn" class="flex items-center text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 transition-colors">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                </svg>
              </button>
              <h1 class="text-xl font-semibold text-gray-900 dark:text-gray-100">
                Mes Élèves (${this.students.length})
              </h1>
              <div class="flex items-center gap-2">
                <button id="temp-photos-btn" class="btn-icon relative" title="Photos sauvegardées">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
                  </svg>
                  <span id="temp-photos-count" class="absolute -top-2 -right-2 px-2 py-1 bg-orange-500 text-white text-xs rounded-full hidden">0</span>
                </button>
                <button id="backup-btn" class="btn-icon" title="Gérer les sauvegardes">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                  </svg>
                </button>
                <button id="import-csv" class="btn-icon" title="Importer depuis CSV">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10"/>
                  </svg>
                </button>
                <button id="add-student" class="btn-primary" title="Ajouter un élève">
                  <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                  </svg>
                  Nouvel Élève
                </button>
              </div>
            </div>
          </div>
        </header>

        <main class="container mx-auto px-4 py-6">
          <div class="flex flex-col sm:flex-row gap-4 mb-6">
            <div class="flex-1">
              <input 
                type="text" 
                id="search-input" 
                class="input" 
                placeholder="Rechercher un élève (nom, prénom)..."
                value="${this.searchQuery}"
              />
            </div>
            <select id="sort-select" class="input sm:w-48">
              <option value="nom" ${this.sortBy==="nom"?"selected":""}>Trier par nom</option>
              <option value="prenom" ${this.sortBy==="prenom"?"selected":""}>Trier par prénom</option>
              <option value="createdAt" ${this.sortBy==="createdAt"?"selected":""}>Plus récents</option>
              <option value="progression" ${this.sortBy==="progression"?"selected":""}>📈 Progression générale</option>
            </select>
          </div>

          ${this.filteredStudents.length>0?`
            <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              ${this.filteredStudents.map(t=>this.renderStudentCard(t)).join("")}
            </div>
          `:`
            <div class="text-center py-12">
              <svg class="w-12 h-12 mx-auto text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
              </svg>
              <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                ${this.searchQuery?"Aucun élève trouvé":"Aucun élève"}
              </h3>
              <p class="text-gray-600 dark:text-gray-400 mb-4">
                ${this.searchQuery?"Essayez de modifier votre recherche":"Commencez par ajouter vos élèves ou importer une liste CSV"}
              </p>
              ${this.searchQuery?"":`
                <button class="btn-primary" id="cta-add-first">Ajouter mon premier élève</button>
              `}
            </div>
          `}
        </main>

        <student-modal></student-modal>
      </div>
    `,this.attachEvents(),this.updateTempPhotosCount()}renderStudentCard(t){const e=t.naissance?this.calculateAge(t.naissance):null,s=t.sexe==="F"?"♀":t.sexe==="M"?"♂":"",r=this.studentsProgression.get(t.id)||0,o=Math.round(r),a=this.studentsSkillsCount.get(t.id)||{evaluated:0,total:0};let n="bg-gray-300";o>=80?n="bg-green-500":o>=60?n="bg-blue-500":o>=40?n="bg-yellow-500":o>=20?n="bg-orange-500":n="bg-red-500";const d=a.total>0?Math.round(a.evaluated/a.total*100):0;let l="text-gray-600";d>=80?l="text-green-600":d>=60?l="text-blue-600":d>=40?l="text-yellow-600":d>=20?l="text-orange-600":l="text-red-600";const p=t.avatar||t.photo,g=`${t.prenom.charAt(0)||""}${t.nom.charAt(0)||""}`.toUpperCase();return`
      <div class="card bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-4 flex flex-col gap-4 shadow-sm">
        <div class="flex items-start gap-3">
          <div class="w-14 h-14 rounded-full overflow-hidden bg-primary-100 dark:bg-primary-900/40 flex items-center justify-center text-primary-600 dark:text-primary-300 font-semibold text-lg">
            ${p?`<img src="${p}" alt="${t.prenom} ${t.nom}" class="w-full h-full object-cover" />`:g}
          </div>
          <div class="flex-1 min-w-0">
            <h3 class="font-semibold text-gray-900 dark:text-gray-100 truncate">
              ${t.prenom} ${t.nom}
            </h3>
            <div class="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
              ${s?`<span>${s}</span>`:""}
              ${e?`<span>${e} ans</span>`:""}
            </div>
          </div>
        </div>

        ${this.sortBy==="progression"||r>0?`
          <div class="mb-3">
            <div class="flex items-center justify-between text-xs mb-1">
              <span class="text-gray-600 dark:text-gray-400">📈 Progression générale</span>
              <div class="flex items-center gap-2">
                <span class="font-medium text-gray-900 dark:text-gray-100">${o}%</span>
                <span class="${l} font-medium text-xs bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded-full">
                  ${a.evaluated}/${a.total}
                </span>
              </div>
            </div>
            <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-1">
              <div class="${n} h-2 rounded-full transition-all duration-300" style="width: ${o}%"></div>
            </div>
            <div class="text-xs ${l} text-right">
              ${a.evaluated} compétence${a.evaluated>1?"s":""} évaluée${a.evaluated>1?"s":""} sur ${a.total}
            </div>
          </div>
        `:""}

        <div class="flex items-center justify-between text-sm">
          <span class="text-gray-500 dark:text-gray-400">
            Ajouté le ${new Date(t.createdAt).toLocaleDateString("fr-FR")}
          </span>
          <div class="flex gap-1">
            <button class="btn-icon text-primary-600 hover:bg-primary-50" data-action="view" data-student-id="${t.id}" title="Consulter">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
              </svg>
            </button>
            <button class="btn-icon text-blue-600 hover:bg-blue-50" data-action="edit" data-student-id="${t.id}" title="Modifier">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
              </svg>
            </button>
            <button class="btn-icon text-red-600 hover:bg-red-50" data-action="delete" data-student-id="${t.id}" title="Supprimer">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `}calculateAge(t){const e=new Date,s=new Date(t);let r=e.getFullYear()-s.getFullYear();const o=e.getMonth()-s.getMonth();return(o<0||o===0&&e.getDate()<s.getDate())&&r--,r}attachEvents(){this.querySelector("#back-home-btn")?.addEventListener("click",()=>{h.navigateTo({name:"home"})}),this.querySelector("#temp-photos-btn")?.addEventListener("click",()=>{h.navigateTo({name:"temp-photos"})}),this.querySelector("#backup-btn")?.addEventListener("click",()=>{h.navigateTo({name:"backup-manager"})}),[this.querySelector("#add-student"),this.querySelector("#cta-add-first")].filter(Boolean).forEach(r=>r.addEventListener("click",()=>this.openCreateModal())),this.querySelector("#import-csv")?.addEventListener("click",()=>{this.handleCSVImport()});const e=this.querySelector("#search-input");e&&e.addEventListener("input",async r=>{const o=r.target;this.searchQuery=o.value;const a=o.selectionStart??o.value.length;await this.applyFilters(),this.render();const n=this.querySelector("#search-input");n&&(n.focus(),n.setSelectionRange(a,a))}),this.querySelector("#sort-select")?.addEventListener("change",async r=>{this.sortBy=r.target.value,await this.applyFilters(),this.render()}),this.querySelectorAll("[data-action]").forEach(r=>{r.addEventListener("click",o=>{const a=o.currentTarget,n=a.dataset.studentId,d=a.dataset.action;if(!(!n||!d))switch(d){case"view":h.navigateTo({name:"student-detail",studentId:n});break;case"edit":this.openEditModal(n);break;case"delete":this.handleDeleteStudent(n);break}})})}openCreateModal(){this.querySelector("student-modal")?.openForCreate(async()=>{await this.loadStudents()},()=>{})}openEditModal(t){this.querySelector("student-modal")?.openForEdit(t,async()=>{await this.loadStudents()},()=>{})}async handleCSVImport(){const t=await C(".csv");if(t)try{const e=await t.text(),s=await b(e);s.errors.length>0?alert(`Import terminé avec ${s.imported} élèves et ${s.errors.length} erreurs.
${s.errors.join(`
`)}`):alert(`Import réussi ! ${s.imported} élèves ajoutés.`),await this.loadStudents()}catch(e){console.error("Erreur lors de l'import CSV:",e),alert("Erreur lors de l'import du fichier CSV.")}}async handleDeleteStudent(t){if(window.confirm("Confirmez-vous la suppression de cet élève et de son carnet ?"))try{await x(t),await this.loadStudents()}catch(s){console.error("Erreur lors de la suppression de l'élève:",s),alert("Erreur lors de la suppression de l'élève.")}}}customElements.define("students-list",$);export{$ as StudentsList};
