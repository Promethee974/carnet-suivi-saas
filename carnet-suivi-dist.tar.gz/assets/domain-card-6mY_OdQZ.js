var f=Object.defineProperty;var x=(o,r,t)=>r in o?f(o,r,{enumerable:!0,configurable:!0,writable:!0,value:t}):o[r]=t;var n=(o,r,t)=>x(o,typeof r!="symbol"?r+"":r,t);import{a as b}from"./skills-CFwbsuGQ.js";import{getCarnet as g,addPhotoToSkill as $,removePhotoFromSkill as y,updateSkill as k}from"./repo-C_U3TJ5T.js";import{emitSkillUpdate as I,eventManager as p}from"./events-Bt4lVFZr.js";import"./db-BumgrVF8.js";class v extends HTMLElement{constructor(){super(...arguments);n(this,"studentId","");n(this,"skillId","");n(this,"text","")}static get observedAttributes(){return["student-id","data-skill-id","data-text"]}attributeChangedCallback(t,e,s){s&&(t==="student-id"&&(this.studentId=s),t==="data-skill-id"&&(this.skillId=s),t==="data-text"&&(this.text=s),this.render())}connectedCallback(){this.render()}async render(){if(!this.studentId||!this.skillId)return;const t=await g(this.studentId);if(!t)return;const e=t.skills[this.skillId];if(!e)return;this.innerHTML=`
      <article class="card p-3" aria-labelledby="skill-${this.skillId}">
        <header class="flex items-start justify-between gap-3">
          <h4 id="skill-${this.skillId}" class="font-medium">${this.text}</h4>
          <div class="radio-group" role="radiogroup" aria-label="État de la compétence">
            ${this.renderRadio("","—",e.status==="")}
            ${this.renderRadio("NA","NA",e.status==="NA")}
            ${this.renderRadio("EC","EC",e.status==="EC")}
            ${this.renderRadio("A","A",e.status==="A")}
          </div>
        </header>
        <div class="mt-3 grid md:grid-cols-2 gap-3">
          <div>
            <label class="text-xs text-gray-500" for="comment-${this.skillId}">Observation</label>
            <textarea id="comment-${this.skillId}" class="textarea h-24" placeholder="Ajouter une observation...">${e.comment||""}</textarea>
          </div>
          <div>
            <photo-gallery skill-id="${this.skillId}"></photo-gallery>
          </div>
        </div>
      </article>
    `;const s=this.querySelector("photo-gallery");s.setPhotos(e.photos||[]),s.setCallbacks(async d=>{await $(this.studentId,this.skillId,d),await this.render()},async d=>{await y(this.studentId,this.skillId,d),await this.render()}),this.querySelectorAll(`input[name="status-${this.skillId}"]`).forEach(d=>{d.addEventListener("change",async i=>{const h=i.target.value;await k(this.studentId,this.skillId,{status:h});const u=this.skillId.split(".")[0];I(this.studentId,this.skillId,u,h)})});const a=this.querySelector(`#comment-${this.skillId}`);let l;a.addEventListener("input",()=>{window.clearTimeout(l),l=window.setTimeout(async()=>{await k(this.studentId,this.skillId,{comment:a.value});const d=this.skillId.split(".")[0];I(this.studentId,this.skillId,d,"comment")},400)})}renderRadio(t,e,s){const a=`status-${this.skillId}-${t||"none"}`;let l="text-gray-600";return e==="A"?l="text-green-600":e==="EC"?l="text-blue-600":e==="NA"&&(l="text-red-600"),`
      <label for="${a}" class="radio-item ${l}">
        <input id="${a}" class="radio-input" type="radio" name="status-${this.skillId}" value="${t}" ${s?"checked":""} />
        <span>${e}</span>
      </label>
    `}}customElements.define("skill-item",v);class w extends HTMLElement{constructor(){super(...arguments);n(this,"studentId","");n(this,"domainId","");n(this,"name","");n(this,"color","bg-gray-400");n(this,"expanded",!1);n(this,"eventListener",null)}static get observedAttributes(){return["student-id","data-domain-id","data-name","data-color","data-percentage","data-acquired","data-total"]}attributeChangedCallback(t,e,s){if(s){switch(t){case"student-id":this.studentId=s;break;case"data-domain-id":this.domainId=s;break;case"data-name":this.name=s;break;case"data-color":this.color=s;break}this.render()}}connectedCallback(){this.setupEventListeners(),this.render()}disconnectedCallback(){this.eventListener&&p.off("skill-updated",this.eventListener)}setupEventListeners(){this.eventListener&&p.off("skill-updated",this.eventListener),this.eventListener=t=>{const e=t.detail;e.studentId===this.studentId&&e.domainId===this.domainId&&this.updateProgressDisplay()},p.on("skill-updated",this.eventListener)}async updateProgressDisplay(){if(!this.studentId||!this.domainId)return;const t=await g(this.studentId);if(!t)return;const e=b(this.domainId);if(!e)return;const s=e.skills.map(c=>t.skills[c.id]).filter(Boolean),a=s.filter(c=>c.status==="A").length,l=s.filter(c=>c.status==="A"||c.status==="EC"||c.status==="NA").length,d=s.length,i=d>0?Math.round(a/d*100):0,h=this.querySelector(".progress-text"),u=this.querySelector(".progress-fill"),m=this.querySelector(".percentage");h&&(h.textContent=`${l}/${d} compétences abordées`),u&&(u.style.width=`${i}%`,u.className=`progress-fill ${i>=80?"bg-green-500":i>=60?"bg-blue-500":i>=40?"bg-yellow-500":"bg-red-500"}`),m&&(m.textContent=`${i}%`,m.className=`font-semibold ${i>=80?"text-green-600":i>=60?"text-blue-600":i>=40?"text-yellow-600":"text-red-600"}`)}async render(){if(!this.studentId)return;const t=await g(this.studentId);if(!t)return;const e=b(this.domainId);if(!e)return;const s=Number(this.getAttribute("data-total")||"0"),a=Number(this.getAttribute("data-percentage")||"0"),d=e.skills.map(i=>t.skills[i.id]).filter(Boolean).filter(i=>i.status==="A"||i.status==="EC"||i.status==="NA").length;this.innerHTML=`
      <article class="card card-hover p-4" role="region" aria-labelledby="title-${this.domainId}">
        <header class="flex items-center justify-between">
          <div class="flex items-center gap-3">
            <div class="w-3 h-10 rounded ${this.color}" aria-hidden="true"></div>
            <div>
              <h3 id="title-${this.domainId}" class="font-semibold text-lg">${this.name}</h3>
              <p class="progress-text text-sm text-gray-500" aria-live="polite">${d}/${s} compétences abordées</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <span class="percentage font-semibold ${a>=80?"text-green-600":a>=60?"text-blue-600":a>=40?"text-yellow-600":"text-red-600"}">${a}%</span>
            <button type="button" class="btn-secondary" id="toggle" aria-expanded="${this.expanded}">
              ${this.expanded?"Réduire":"Détails"}
            </button>
          </div>
        </header>
        <div class="mt-3">
          <div class="progress-bar" aria-label="Progression">
            <div class="progress-fill ${a>=80?"bg-green-500":a>=60?"bg-blue-500":a>=40?"bg-yellow-500":a>=20?"bg-orange-500":"bg-red-500"}" style="width:${a}%"></div>
          </div>
        </div>
        ${this.expanded?`
        <ul class="mt-4 space-y-3" aria-label="Compétences du domaine ${this.name}">
          ${e.skills.map(i=>`
              <li>
                <skill-item student-id="${this.studentId}" data-skill-id="${i.id}" data-text="${i.text.replace(/"/g,"&quot;")}"></skill-item>
              </li>
            `).join("")}
        </ul>
        `:""}
      </article>
    `,this.querySelector("#toggle")?.addEventListener("click",()=>{this.expanded=!this.expanded,this.render()})}}customElements.define("domain-card",w);export{w as DomainCard};
