var f=Object.defineProperty;var b=(d,r,a)=>r in d?f(d,r,{enumerable:!0,configurable:!0,writable:!0,value:a}):d[r]=a;var m=(d,r,a)=>b(d,typeof r!="symbol"?r+"":r,a);import{a as y,u as x,c as w}from"./students-repo-DiS-lCzz.js";const k={maxWidth:1280,maxHeight:1280,quality:.85,format:"jpeg"};function E(d,r={}){return new Promise((a,e)=>{const t={...k,...r},s=document.createElement("canvas"),i=s.getContext("2d"),o=new Image;if(!i){e(new Error("Impossible de créer le contexte canvas"));return}o.onload=()=>{let{width:l,height:c}=o;if(l>t.maxWidth||c>t.maxHeight){const h=Math.min(t.maxWidth/l,t.maxHeight/c);l*=h,c*=h}s.width=l,s.height=c,i.drawImage(o,0,0,l,c);const p=t.format==="jpeg"?"image/jpeg":t.format==="webp"?"image/webp":"image/png",g=s.toDataURL(p,t.quality);a(g)},o.onerror=()=>{e(new Error("Erreur lors du chargement de l'image"))};const u=URL.createObjectURL(d);o.src=u;const n=o.onload;o.onload=()=>{URL.revokeObjectURL(u),n&&n.call(o,new Event("load"))}})}async function C(){return new Promise(async(d,r)=>{let a=null;try{a=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment",width:{ideal:1280},height:{ideal:720}}});const e=document.createElement("div");e.className="modal-overlay",e.innerHTML=`
        <div class="modal-content max-w-4xl">
          <div class="p-4">
            <div class="flex justify-between items-center mb-4">
              <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">📸 Prévisualisation caméra</h3>
              <button type="button" class="btn-icon" id="close-camera">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
              </button>
            </div>
            
            <div class="relative bg-black rounded-lg overflow-hidden mb-4">
              <video id="camera-preview" autoplay playsinline class="w-full h-auto max-h-96 object-contain"></video>
              <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div class="w-64 h-64 border-2 border-white border-dashed rounded-lg opacity-50"></div>
              </div>
            </div>
            
            <div class="text-center text-sm text-gray-600 dark:text-gray-400 mb-4">
              Cadrez votre photo et cliquez sur "Capturer" quand vous êtes prêt
            </div>
            
            <div class="flex justify-center gap-4">
              <button type="button" class="btn-secondary" id="cancel-camera">
                ❌ Annuler
              </button>
              <button type="button" class="btn-primary" id="capture-photo">
                📸 Capturer la photo
              </button>
            </div>
          </div>
        </div>
      `,document.body.appendChild(e);const t=e.querySelector("#camera-preview");t.srcObject=a;const s=()=>{a&&a.getTracks().forEach(n=>n.stop()),document.body.contains(e)&&document.body.removeChild(e)},i=()=>{s(),r(new Error("Capture annulée par l'utilisateur"))},o=()=>{try{const n=document.createElement("canvas"),l=n.getContext("2d");if(!l)throw new Error("Impossible de créer le contexte canvas");n.width=t.videoWidth,n.height=t.videoHeight,l.drawImage(t,0,0);const c=n.toDataURL("image/jpeg",.85);s(),d(c)}catch(n){s(),r(n)}};e.querySelector("#close-camera")?.addEventListener("click",i),e.querySelector("#cancel-camera")?.addEventListener("click",i),e.querySelector("#capture-photo")?.addEventListener("click",o),e.addEventListener("click",n=>{n.target===e&&i()});const u=n=>{n.key==="Escape"&&(i(),document.removeEventListener("keydown",u))};document.addEventListener("keydown",u),t.onerror=()=>{s(),r(new Error("Erreur lors de l'accès à la caméra"))}}catch{a&&a.getTracks().forEach(t=>t.stop()),r(new Error("Caméra non disponible ou accès refusé"))}})}function M(){return`photo_${Date.now()}_${Math.random().toString(36).substr(2,9)}`}class v extends HTMLElement{constructor(){super();m(this,"student",null);m(this,"isEditing",!1);m(this,"onSave");m(this,"onCancel")}openForCreate(a,e){this.student=null,this.isEditing=!1,this.onSave=a,this.onCancel=e,this.render(),this.show()}async openForEdit(a,e,t){this.student=await y(a),this.isEditing=!0,this.onSave=e,this.onCancel=t,this.render(),this.show()}show(){this.style.display="flex",document.body.style.overflow="hidden",setTimeout(()=>{this.querySelector("input")?.focus()},100)}hide(){this.style.display="none",document.body.style.overflow=""}render(){this.className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",this.style.display="none",this.innerHTML=`
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
          <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100">
              ${this.isEditing?"Modifier l'élève":"Nouvel élève"}
            </h2>
            <button id="close-btn" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>

          <form id="student-form" class="space-y-4">
            <!-- Avatar -->
            <div class="text-center">
              <div class="relative inline-block">
                <div id="avatar-preview" class="w-24 h-24 rounded-full overflow-hidden bg-gray-100 dark:bg-gray-700 flex items-center justify-center mx-auto mb-3">
                  ${this.student?.avatar?`
                    <img src="${this.student.avatar}" alt="Avatar" class="w-full h-full object-cover" />
                  `:`
                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                  `}
                </div>
                <button type="button" id="change-avatar" class="absolute bottom-0 right-0 bg-blue-600 text-white rounded-full p-2 hover:bg-blue-700">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/>
                  </svg>
                </button>
              </div>
              <input type="file" id="avatar-input" accept="image/*" class="hidden" />
            </div>

            <!-- Nom -->
            <div>
              <label for="nom" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nom <span class="text-red-500">*</span>
              </label>
              <input 
                type="text" 
                id="nom" 
                name="nom" 
                required
                value="${this.student?.nom||""}"
                class="input w-full"
                placeholder="Nom de famille"
              />
            </div>

            <!-- Prénom -->
            <div>
              <label for="prenom" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Prénom <span class="text-red-500">*</span>
              </label>
              <input 
                type="text" 
                id="prenom" 
                name="prenom" 
                required
                value="${this.student?.prenom||""}"
                class="input w-full"
                placeholder="Prénom"
              />
            </div>

            <!-- Sexe -->
            <div>
              <label for="sexe" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Sexe
              </label>
              <select id="sexe" name="sexe" class="input w-full">
                <option value="">Non spécifié</option>
                <option value="F" ${this.student?.sexe==="F"?"selected":""}>Féminin</option>
                <option value="M" ${this.student?.sexe==="M"?"selected":""}>Masculin</option>
                <option value="Autre" ${this.student?.sexe==="Autre"?"selected":""}>Autre</option>
                <option value="ND" ${this.student?.sexe==="ND"?"selected":""}>Ne souhaite pas dire</option>
              </select>
            </div>

            <!-- Date de naissance -->
            <div>
              <label for="naissance" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Date de naissance
              </label>
              <input 
                type="date" 
                id="naissance" 
                name="naissance" 
                value="${this.student?.naissance||""}"
                class="input w-full"
              />
            </div>

            <!-- Boutons -->
            <div class="flex gap-3 pt-4">
              <button type="button" id="cancel-btn" class="btn-secondary flex-1">
                Annuler
              </button>
              <button type="submit" class="btn-primary flex-1">
                ${this.isEditing?"Enregistrer":"Créer"}
              </button>
            </div>
          </form>
        </div>
      </div>
    `,this.attachEvents()}attachEvents(){this.querySelector("#close-btn")?.addEventListener("click",()=>this.handleCancel()),this.querySelector("#cancel-btn")?.addEventListener("click",()=>this.handleCancel()),this.addEventListener("click",e=>{e.target===this&&this.handleCancel()});const a=e=>{e.key==="Escape"&&(this.handleCancel(),document.removeEventListener("keydown",a))};document.addEventListener("keydown",a),this.querySelector("#change-avatar")?.addEventListener("click",()=>{this.querySelector("#avatar-input").click()}),this.querySelector("#avatar-input")?.addEventListener("change",async e=>{const t=e.target.files?.[0];if(t)try{const s=await E(t),i=this.querySelector("#avatar-preview");i.innerHTML=`<img src="${s}" alt="Avatar" class="w-full h-full object-cover" />`}catch(s){console.error("Erreur compression image:",s),alert("Erreur lors du traitement de l'image")}}),this.querySelector("#student-form")?.addEventListener("submit",e=>{e.preventDefault(),this.handleSubmit()})}handleCancel(){this.hide(),this.onCancel?.()}async handleSubmit(){const a=this.querySelector("#student-form"),e=new FormData(a),t=e.get("nom").trim(),s=e.get("prenom").trim(),i=e.get("sexe"),o=e.get("naissance");if(!t||!s){alert("Le nom et le prénom sont obligatoires");return}try{const n=this.querySelector("#avatar-preview img")?.src||void 0;let l;if(this.isEditing){if(!this.student)throw new Error("Aucun élève à modifier");const c=await x(this.student.id,{nom:t,prenom:s,sexe:i||void 0,naissance:o||void 0,avatar:n});if(!c)throw new Error("Erreur lors de la modification de l'élève");l=c}else l=await w({nom:t,prenom:s,sexe:i||void 0,naissance:o||void 0,avatar:n});this.hide(),this.onSave?.(l)}catch(u){console.error("Erreur sauvegarde élève:",u),alert("Erreur lors de la sauvegarde")}}}customElements.define("student-modal",v);const q=Object.freeze(Object.defineProperty({__proto__:null,StudentModal:v},Symbol.toStringTag,{value:"Module"}));export{E as a,C as c,M as g,q as s};
