var D=Object.defineProperty;var w=(o,r,t)=>r in o?D(o,r,{enumerable:!0,configurable:!0,writable:!0,value:t}):o[r]=t;var d=(o,r,t)=>w(o,typeof r!="symbol"?r+"":r,t);import{a as A}from"./students-repo-DiS-lCzz.js";import{getCarnet as x}from"./repo-C_U3TJ5T.js";import{g as v}from"./skills-CFwbsuGQ.js";import{c as E}from"./progress-DaqdkWEI.js";import{router as C}from"./router-CANAWL_W.js";import"./db-BumgrVF8.js";class S extends HTMLElement{constructor(){super(...arguments);d(this,"studentId","");d(this,"student",null);d(this,"carnet",null)}static get observedAttributes(){return["student-id"]}attributeChangedCallback(t,s,n){t==="student-id"&&n&&(this.studentId=n,this.loadData())}connectedCallback(){this.studentId&&this.loadData()}async loadData(){if(this.studentId)try{if(this.student=await A(this.studentId),this.carnet=await x(this.studentId),!this.student||!this.carnet){this.innerHTML='<div class="error">Élève ou carnet introuvable</div>';return}this.render()}catch(t){console.error("Erreur chargement données impression:",t),this.innerHTML='<div class="error">Erreur de chargement</div>'}}calculateAge(t){if(!t)return 0;try{const s=new Date(t),n=new Date;let i=n.getFullYear()-s.getFullYear();const e=n.getMonth()-s.getMonth();return(e<0||e===0&&n.getDate()<s.getDate())&&i--,i}catch(s){return console.error("Erreur calcul âge:",s),0}}renderDomains(){return this.carnet?v(!0).map(s=>{const n=s.skills.map(i=>{const e=this.carnet?.skills[i.id];return!e||e.status===""?null:`
            <div class="skill-entry">
              <span class="skill-status ${e.status}">
                ${e.status==="A"?"✓":e.status==="EC"?"~":"✗"}
              </span>
              <span class="skill-text">${i.text}</span>
              ${e.comment?`<div class="skill-comment">${e.comment}</div>`:""}
            </div>
          `}).filter(Boolean).join("");return n?`
        <div class="domain-section">
          <h3 class="domain-title" style="color: ${s.color}">
            ${s.name}
          </h3>
          <div class="skills-list">
            ${n}
          </div>
        </div>
      `:""}).join(""):""}render(){if(!this.student||!this.carnet)return;const t=this.student.naissance||this.student.birthDate||"",s=this.calculateAge(t),n=t?new Date(t).toLocaleDateString("fr-FR"):"Non renseignée",i=`
      <header class="print-screen-header">
        <a href="#/students/${this.studentId}" class="back-btn">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="19" y1="12" x2="5" y2="12"></line>
            <polyline points="12 19 5 12 12 5"></polyline>
          </svg>
          Retour
        </a>
        <h2>${this.student.prenom} ${this.student.nom} - Aperçu d'impression</h2>
      </header>
    `,e=this.student.photo||this.student.avatar,m=this.student.prenom.charAt(0)+this.student.nom.charAt(0),g=`
      <div class="print-layout">
        <div class="print-header">
          <div class="school-info">
            <h1>École Maternelle</h1>
            <h2>Carnet de suivi des apprentissages</h2>
          </div>
          <div class="student-info">
            <div class="student-avatar">
              ${e?`
                <img src="${e}" alt="${this.student.prenom} ${this.student.nom}" />
              `:`
                <div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: #e5e7eb; color: #6b7280; font-weight: bold;">
                  ${m}
                </div>
              `}
            </div>
            <div class="student-details">
              <h3>${this.student.prenom} ${this.student.nom}</h3>
              <p>Né(e) le: ${n}</p>
              <p>Âge: ${s>0?`${s} ans`:"Non spécifié"}</p>
            </div>
          </div>
        </div>
        
        ${this.renderDomains()}
        
        <div class="print-footer">
          <p>Établissement: École Maternelle - Année scolaire 2023-2024</p>
          <p>Document généré le: ${new Date().toLocaleDateString("fr-FR")}</p>
        </div>
      </div>
    `,f=`
      <footer class="print-screen-footer">
        <button id="print-btn" class="print-btn">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="6 9 6 2 18 2 18 9"></polyline>
            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
            <rect x="6" y="14" width="12" height="8"></rect>
          </svg>
          Imprimer
        </button>
      </footer>
    `;this.innerHTML=i+g+f;const b=v(!0).filter(a=>a.skills.some(k=>{const c=this.carnet.skills[k.id];return c&&(c.status==="NA"||c.status==="EC"||c.status==="A")})),l=Object.values(this.carnet.skills).filter(a=>a.status==="NA"||a.status==="EC"||a.status==="A"),u=l.length,h=l.filter(a=>a.status==="A").length,$=l.filter(a=>a.status==="EC").length,y=l.filter(a=>a.status==="NA").length,p=u>0?Math.round(h/u*100):0;this.innerHTML=`
      <div class="print-layout">
        <!-- En-tête -->
        <header class="print-header">
          <div class="school-info">
            <h1>Carnet de Suivi des Apprentissages</h1>
            <h2>Grande Section - Programmes 2025</h2>
          </div>
          <div class="student-info">
            <div class="student-avatar">
              ${this.student.avatar?`
                <img src="${this.student.avatar}" alt="Photo de ${this.student.prenom}" />
              `:`
                <div class="avatar-placeholder">
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                  </svg>
                </div>
              `}
            </div>
            <div class="student-details">
              <h3>${this.student.prenom} ${this.student.nom}</h3>
              ${this.student.naissance?`<p>Né(e) le ${this.formatDate(this.student.naissance)}</p>`:""}
              ${this.student.sexe?`<p>${this.student.sexe==="F"?"Fille":this.student.sexe==="M"?"Garçon":this.student.sexe}</p>`:""}
            </div>
          </div>
        </header>

        <!-- Informations du carnet -->
        <section class="carnet-info">
          <div class="info-grid">
            <div class="info-item">
              <strong>Année scolaire :</strong> ${this.carnet.meta.annee}-${parseInt(this.carnet.meta.annee)+1}
            </div>
            <div class="info-item">
              <strong>Enseignant(e) :</strong> ${this.carnet.meta.enseignant}
            </div>
            <div class="info-item">
              <strong>Période :</strong> Période ${this.carnet.meta.periode}
            </div>
            <div class="info-item">
              <strong>Date d'édition :</strong> ${this.formatDate(new Date().toISOString().split("T")[0])}
            </div>
          </div>
        </section>

        <!-- Synthèse globale -->
        <section class="global-summary">
          <h2>Synthèse Globale</h2>
          <div class="summary-stats">
            <div class="stat-item acquired">
              <span class="stat-number">${h}</span>
              <span class="stat-label">Acquises</span>
            </div>
            <div class="stat-item in-progress">
              <span class="stat-number">${$}</span>
              <span class="stat-label">En cours</span>
            </div>
            <div class="stat-item not-acquired">
              <span class="stat-number">${y}</span>
              <span class="stat-label">Non acquises</span>
            </div>
            <div class="stat-item total">
              <span class="stat-number">${p}%</span>
              <span class="stat-label">Progression</span>
            </div>
          </div>
          <div class="progress-bar-print">
            <div class="progress-fill-print" style="width: ${p}%"></div>
          </div>
        </section>

        <!-- Domaines évalués -->
        ${b.map(a=>this.renderDomainForPrint(a)).join("")}

        <!-- Synthèse personnalisée -->
        ${this.carnet.synthese&&(this.carnet.synthese.forces||this.carnet.synthese.axes||this.carnet.synthese.projets)?`
          <section class="personal-synthesis">
            <h2>Synthèse Personnalisée</h2>
            ${this.carnet.synthese.forces?`
              <div class="synthesis-section">
                <h3>Points forts</h3>
                <p>${this.carnet.synthese.forces}</p>
              </div>
            `:""}
            ${this.carnet.synthese.axes?`
              <div class="synthesis-section">
                <h3>Axes de progrès</h3>
                <p>${this.carnet.synthese.axes}</p>
              </div>
            `:""}
            ${this.carnet.synthese.projets?`
              <div class="synthesis-section">
                <h3>Projets et perspectives</h3>
                <p>${this.carnet.synthese.projets}</p>
              </div>
            `:""}
          </section>
        `:""}

        <!-- Pied de page -->
        <footer class="print-footer">
          <div class="signatures">
            <div class="signature-block">
              <p><strong>L'enseignant(e)</strong></p>
              <div class="signature-line"></div>
            </div>
            <div class="signature-block">
              <p><strong>Les parents</strong></p>
              <div class="signature-line"></div>
            </div>
          </div>
          <p class="footer-note">
            Ce carnet de suivi est conforme aux programmes de l'école maternelle (BO spécial n°2 du 26 mars 2015)
          </p>
        </footer>

        <!-- Boutons d'action (masqués à l'impression) -->
        <div class="print-actions no-print">
          <button id="back-btn" class="btn-secondary">
            ← Retour au carnet
          </button>
          <button id="print-btn" class="btn-primary">
            🖨️ Imprimer
          </button>
        </div>
      </div>
    `,this.attachEvents()}renderDomainForPrint(t){if(!this.carnet)return"";const s=t.skills.filter(i=>{const e=this.carnet.skills[i.id];return e&&(e.status==="NA"||e.status==="EC"||e.status==="A")});if(s.length===0)return"";const n=E(t.id,this.carnet.skills);return`
      <section class="domain-section">
        <div class="domain-header">
          <div class="domain-title">
            <div class="domain-color" style="background-color: ${this.getColorValue(t.color)}"></div>
            <h2>${t.name}</h2>
          </div>
          <div class="domain-stats">
            <span class="domain-progress">${n.acquired}/${n.total} acquises (${n.percentage}%)</span>
          </div>
        </div>
        
        <div class="skills-grid">
          ${s.map(i=>this.renderSkillForPrint(i)).join("")}
        </div>
      </section>
    `}renderSkillForPrint(t){if(!this.carnet)return"";const s=this.carnet.skills[t.id];if(!s||!s.status)return"";const n=s.status==="A"?"acquired":s.status==="EC"?"in-progress":"not-acquired",i=s.status==="A"?"Acquise":s.status==="EC"?"En cours":"Non acquise";return`
      <div class="skill-item">
        <div class="skill-header">
          <span class="skill-text">${t.text}</span>
          <span class="skill-status ${n}">${i}</span>
        </div>
        ${s.comment?`
          <div class="skill-comment">
            <p>${s.comment}</p>
          </div>
        `:""}
      </div>
    `}getColorValue(t){return{"bg-red-400":"#f87171","bg-orange-400":"#fb923c","bg-yellow-400":"#fbbf24","bg-green-400":"#4ade80","bg-blue-400":"#60a5fa","bg-indigo-400":"#818cf8","bg-purple-400":"#c084fc","bg-pink-400":"#f472b6"}[t]||"#6b7280"}formatDate(t){return new Date(t).toLocaleDateString("fr-FR",{year:"numeric",month:"long",day:"numeric"})}attachEvents(){this.querySelector("#back-btn")?.addEventListener("click",()=>{C.goToStudentDetail(this.studentId)}),this.querySelector("#print-btn")?.addEventListener("click",()=>{window.print()})}}customElements.define("student-print",S);export{S as StudentPrint};
