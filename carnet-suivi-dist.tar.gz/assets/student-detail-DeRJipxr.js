const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/temp-photos-BVCntkeW.js","assets/main-CA8ihvBi.js","assets/main-uwlzZ6gw.css","assets/db-BumgrVF8.js"])))=>i.map(i=>d[i]);
var E=Object.defineProperty;var P=(r,n,t)=>n in r?E(r,n,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[n]=t;var c=(r,n,t)=>P(r,typeof n!="symbol"?n+"":n,t);import{a as x}from"./students-repo-DiS-lCzz.js";import{getCarnet as v,getSetting as k,initializeCarnet as C}from"./repo-C_U3TJ5T.js";import{g as f}from"./skills-CFwbsuGQ.js";import{c as w,a as L,b as S}from"./progress-DaqdkWEI.js";import{router as j}from"./router-CANAWL_W.js";import"./domain-card-6mY_OdQZ.js";import{_ as b}from"./main-CA8ihvBi.js";import{c as I,a as M,g as q}from"./student-modal-CsP6WSdO.js";import{eventManager as g}from"./events-Bt4lVFZr.js";import"./meta-modal-2sVvQ4ZO.js";import"./synthese-modal-BeXhjiFE.js";import"./db-BumgrVF8.js";async function A(r){try{const n=await x(r),t=await v(r);if(!n||!t){alert("Impossible de charger les données de l'élève pour l'impression");return}const o=D(n,t),s=window.open("","_blank","width=800,height=600");if(!s){alert("Impossible d'ouvrir la fenêtre d'impression. Vérifiez que les popups ne sont pas bloqués.");return}s.document.write(`
      <!DOCTYPE html>
      <html lang="fr">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Carnet de ${n.prenom} ${n.nom}</title>
        <style>
          ${N()}
        </style>
      </head>
      <body>
        ${o}
      </body>
      </html>
    `),s.document.close(),s.onload=()=>{setTimeout(()=>{s.print(),s.close()},500)}}catch(n){console.error("Erreur lors de l'impression:",n),alert("Erreur lors de la génération du document d'impression")}}function D(r,n){const o=f(!0).filter(i=>i.skills.some(d=>{const l=n.skills[d.id];return l&&(l.status==="EC"||l.status==="A")})),s=Object.values(n.skills).filter(i=>i.status==="EC"||i.status==="A"),e=s.filter(i=>i.status==="A").length,a=s.filter(i=>i.status==="EC").length;return`
    <div class="print-layout">
      <!-- En-tête -->
      <header class="print-header">
        <div class="school-info">
          <h1>Carnet de Suivi des Apprentissages</h1>
          <h2>Grande Section - Programmes 2025</h2>
        </div>
        <div class="student-info">
          <div class="student-avatar">
            ${r.avatar?`
              <img src="${r.avatar}" alt="Photo de ${r.prenom}" />
            `:`
              <div class="avatar-placeholder">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
              </div>
            `}
          </div>
          <div class="student-details">
            <h3>${r.prenom} ${r.nom}</h3>
            ${r.naissance?`<p>Né(e) le ${y(r.naissance)}</p>`:""}
            ${r.sexe?`<p>${r.sexe==="F"?"Fille":r.sexe==="M"?"Garçon":r.sexe}</p>`:""}
          </div>
        </div>
      </header>

      <!-- Informations du carnet -->
      <section class="carnet-info">
        <div class="info-grid">
          <div class="info-item">
            <strong>Année scolaire :</strong> ${n.meta.annee}-${parseInt(n.meta.annee)+1}
          </div>
          <div class="info-item">
            <strong>Enseignant(e) :</strong> ${n.meta.enseignant}
          </div>
          <div class="info-item">
            <strong>Période :</strong> Période ${n.meta.periode}
          </div>
          <div class="info-item">
            <strong>Date d'édition :</strong> ${y(new Date().toISOString().split("T")[0])}
          </div>
          <div class="info-item">
            <strong>Compétences acquises :</strong> ${e}
          </div>
          <div class="info-item">
            <strong>Compétences en cours :</strong> ${a}
          </div>
        </div>
      </section>

      <!-- Domaines évalués -->
      ${o.map(i=>z(i,n)).join("")}

      <!-- Synthèse personnalisée -->
      ${n.synthese&&(n.synthese.forces||n.synthese.axes||n.synthese.projets)?`
        <section class="personal-synthesis">
          <h2>Synthèse Personnalisée</h2>
          ${n.synthese.forces?`
            <div class="synthesis-section">
              <h3>Points forts</h3>
              <p>${n.synthese.forces}</p>
            </div>
          `:""}
          ${n.synthese.axes?`
            <div class="synthesis-section">
              <h3>Axes de progrès</h3>
              <p>${n.synthese.axes}</p>
            </div>
          `:""}
          ${n.synthese.projets?`
            <div class="synthesis-section">
              <h3>Projets et perspectives</h3>
              <p>${n.synthese.projets}</p>
            </div>
          `:""}
        </section>
      `:""}

      <!-- Pied de page -->
      <footer class="print-footer">
        <div class="signatures">
          <div class="signature-block">
            <p><strong>L'enseignant(e)</strong></p>
            <div class="signature-line"></div>
          </div>
          <div class="signature-block">
            <p><strong>Les parents</strong></p>
            <div class="signature-line"></div>
          </div>
        </div>
        <p class="footer-note">
          Ce carnet de suivi est conforme aux programmes de l'école maternelle (BO spécial n°2 du 26 mars 2015)
        </p>
      </footer>
    </div>
  `}function z(r,n){const t=r.skills.filter(s=>{const e=n.skills[s.id];return e&&(e.status==="EC"||e.status==="A")});if(t.length===0)return"";const o=w(r.id,n.skills);return`
    <section class="domain-section">
      <div class="domain-header">
        <div class="domain-title">
          <div class="domain-color" style="background-color: ${H(r.color)}"></div>
          <h2>${r.name}</h2>
        </div>
        <div class="domain-stats">
          <span class="domain-progress">${o.acquired}/${o.total} acquises (${o.percentage}%)</span>
        </div>
      </div>
      
      <div class="skills-grid">
        ${t.map(s=>T(s,n)).join("")}
      </div>
    </section>
  `}function T(r,n){const t=n.skills[r.id];if(!t||!t.status)return"";const o=t.status==="A"?"acquired":t.status==="EC"?"in-progress":"not-acquired",s=t.status==="A"?"Acquise":t.status==="EC"?"En cours":"Non acquise";return`
    <div class="skill-item">
      <div class="skill-header">
        <span class="skill-text">${r.text}</span>
        <span class="skill-status ${o}">${s}</span>
      </div>
      ${t.comment?`
        <div class="skill-comment">
          <p>${t.comment}</p>
        </div>
      `:""}
      ${t.photos&&t.photos.length>0?B(t.photos):""}
    </div>
  `}function B(r){if(!r||r.length===0)return"";const n=r.slice(0,4),t=r.length-n.length;return`
    <div class="skill-photos">
      <div class="photos-grid ${R(n.length)}">
        ${n.map(o=>`
          <div class="photo-item">
            <img src="${o.dataURL}" alt="Photo compétence" />
            ${o.caption?`<div class="photo-caption">${o.caption}</div>`:""}
          </div>
        `).join("")}
        ${t>0?`
          <div class="photo-item more-photos">
            <div class="more-photos-indicator">
              <span class="more-count">+${t}</span>
              <span class="more-text">photo${t>1?"s":""}</span>
            </div>
          </div>
        `:""}
      </div>
    </div>
  `}function R(r){switch(r){case 1:return"photos-grid-1";case 2:return"photos-grid-2";case 3:return"photos-grid-3";case 4:return"photos-grid-4";default:return"photos-grid-4"}}function H(r){return{"bg-red-400":"#f87171","bg-orange-400":"#fb923c","bg-yellow-400":"#fbbf24","bg-green-400":"#4ade80","bg-blue-400":"#60a5fa","bg-indigo-400":"#818cf8","bg-purple-400":"#c084fc","bg-pink-400":"#f472b6"}[r]||"#6b7280"}function y(r){return new Date(r).toLocaleDateString("fr-FR",{year:"numeric",month:"long",day:"numeric"})}function N(){return`
    /* Reset et base */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      color-adjust: exact !important;
    }
    
    body {
      font-family: 'Times New Roman', serif;
      font-size: 12pt;
      line-height: 1.4;
      color: #000;
      background: #fff;
    }
    
    /* Layout principal */
    .print-layout {
      max-width: 190mm;
      margin: 0 auto;
      padding: 10mm;
    }
    
    /* En-tête */
    .print-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 20pt;
      padding-bottom: 15pt;
      border-bottom: 2pt solid #000;
    }
    
    .school-info h1 {
      font-size: 20pt;
      font-weight: bold;
      margin-bottom: 5pt;
    }
    
    .school-info h2 {
      font-size: 14pt;
      color: #666;
    }
    
    .student-info {
      display: flex;
      align-items: center;
      gap: 10pt;
    }
    
    .student-avatar {
      width: 60pt;
      height: 60pt;
      border-radius: 50%;
      overflow: hidden;
      border: 1pt solid #ddd;
    }
    
    .student-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .avatar-placeholder {
      width: 100%;
      height: 100%;
      background: #f0f0f0;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #999;
    }
    
    .avatar-placeholder svg {
      width: 30pt;
      height: 30pt;
    }
    
    .student-details h3 {
      font-size: 16pt;
      font-weight: bold;
      margin-bottom: 3pt;
    }
    
    .student-details p {
      font-size: 12pt;
      color: #666;
      margin: 1pt 0;
    }
    
    /* Informations carnet */
    .carnet-info {
      margin-bottom: 20pt;
      padding: 10pt;
      background: #f8f9fa;
      border: 1pt solid #ddd;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8pt;
    }
    
    .info-item {
      font-size: 11pt;
    }
    
    /* Domaines */
    .domain-section {
      margin-bottom: 20pt;
      page-break-inside: avoid;
    }
    
    .domain-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10pt;
      padding: 8pt;
      background: #f0f0f0;
      border: 1pt solid #ccc;
    }
    
    .domain-title {
      display: flex;
      align-items: center;
      gap: 8pt;
    }
    
    .domain-color {
      width: 15pt;
      height: 15pt;
      border-radius: 2pt;
    }
    
    .domain-title h2 {
      font-size: 14pt;
      font-weight: bold;
    }
    
    .domain-stats {
      font-size: 12pt;
      font-weight: bold;
    }
    
    /* Compétences */
    .skills-grid {
      display: grid;
      gap: 8pt;
    }
    
    .skill-item {
      padding: 8pt;
      border: 1pt solid #ddd;
      background: #fff;
      page-break-inside: avoid;
    }
    
    .skill-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 4pt;
    }
    
    .skill-text {
      font-size: 11pt;
      flex: 1;
      margin-right: 8pt;
    }
    
    .skill-status {
      font-size: 10pt;
      font-weight: bold;
      padding: 2pt 6pt;
      border-radius: 8pt;
      white-space: nowrap;
    }
    
    .skill-status.acquired {
      background: #d1fae5;
      color: #059669;
    }
    
    .skill-status.in-progress {
      background: #dbeafe;
      color: #2563eb;
    }
    
    .skill-status.not-acquired {
      background: #fee2e2;
      color: #dc2626;
    }
    
    .skill-comment {
      margin-top: 6pt;
      padding: 6pt;
      background: #f9fafb;
      border-left: 2pt solid #d1d5db;
      font-style: italic;
      font-size: 10pt;
    }
    
    /* Photos des compétences */
    .skill-photos {
      margin-top: 8pt;
      padding-top: 8pt;
      border-top: 1pt solid #e5e7eb;
    }
    
    .photos-grid {
      display: grid;
      gap: 4pt;
      margin-bottom: 4pt;
    }
    
    .photos-grid-1 {
      grid-template-columns: 1fr;
      max-width: 80pt;
    }
    
    .photos-grid-2 {
      grid-template-columns: 1fr 1fr;
      max-width: 160pt;
    }
    
    .photos-grid-3 {
      grid-template-columns: 1fr 1fr 1fr;
      max-width: 240pt;
    }
    
    .photos-grid-4 {
      grid-template-columns: 1fr 1fr 1fr 1fr;
      max-width: 320pt;
    }
    
    .photo-item {
      position: relative;
      aspect-ratio: 1;
      overflow: hidden;
      border-radius: 3pt;
      border: 1pt solid #d1d5db;
      background: #f9fafb;
    }
    
    .photo-item img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    
    .photo-caption {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: rgba(0, 0, 0, 0.7);
      color: white;
      font-size: 8pt;
      padding: 2pt 4pt;
      line-height: 1.2;
      max-height: 50%;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .more-photos {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f3f4f6;
      border: 2pt dashed #9ca3af;
    }
    
    .more-photos-indicator {
      text-align: center;
      color: #6b7280;
    }
    
    .more-count {
      display: block;
      font-size: 14pt;
      font-weight: bold;
      line-height: 1;
    }
    
    .more-text {
      display: block;
      font-size: 8pt;
      margin-top: 2pt;
    }
    
    /* Synthèse personnalisée */
    .personal-synthesis {
      margin-top: 25pt;
      page-break-before: always;
    }
    
    .personal-synthesis h2 {
      font-size: 16pt;
      font-weight: bold;
      margin-bottom: 15pt;
      text-align: center;
    }
    
    .synthesis-section {
      margin-bottom: 15pt;
    }
    
    .synthesis-section h3 {
      font-size: 12pt;
      font-weight: bold;
      margin-bottom: 6pt;
      color: #374151;
    }
    
    .synthesis-section p {
      font-size: 11pt;
      line-height: 1.5;
      padding: 8pt;
      border: 1pt solid #d1d5db;
      background: #f9fafb;
      min-height: 40pt;
    }
    
    /* Pied de page */
    .print-footer {
      margin-top: 30pt;
      padding-top: 15pt;
      border-top: 1pt solid #ccc;
    }
    
    .signatures {
      display: flex;
      justify-content: space-between;
      margin-bottom: 15pt;
    }
    
    .signature-block {
      text-align: center;
      width: 150pt;
    }
    
    .signature-block p {
      margin-bottom: 8pt;
      font-weight: bold;
    }
    
    .signature-line {
      height: 1pt;
      background: #000;
      margin-top: 30pt;
    }
    
    .footer-note {
      text-align: center;
      font-size: 9pt;
      color: #666;
    }
    
    /* Optimisations impression */
    @page {
      margin: 15mm;
      size: A4;
    }
    
    @media print {
      .print-layout {
        max-width: none;
        margin: 0;
        padding: 0;
      }
    }
  `}class O extends HTMLElement{constructor(){super();c(this,"photos",[]);c(this,"_skillId","");c(this,"onPhotoAdd");c(this,"onPhotoRemove");this.render()}get skillId(){return this._skillId}static get observedAttributes(){return["skill-id"]}attributeChangedCallback(t,o,s){t==="skill-id"&&s!==o&&(this._skillId=s)}setPhotos(t){this.photos=t,this.render()}setCallbacks(t,o){this.onPhotoAdd=t,this.onPhotoRemove=o}render(){this.innerHTML=`
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300">
            Photos (${this.photos.length})
          </h4>
          <div class="flex gap-2">
            <button type="button" class="btn-icon" id="add-from-camera" title="Prendre une photo">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
            </button>
            <button type="button" class="btn-icon" id="add-from-gallery" title="Choisir une photo">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
              </svg>
            </button>
          </div>
        </div>
        
        ${this.photos.length>0?`
          <div class="photo-grid">
            ${this.photos.map(t=>`
              <div class="space-y-1" data-photo-id="${t.id}">
                <div class="photo-thumbnail group relative">
                  <img src="${t.dataURL}" alt="${t.caption||"Photo"}" class="w-full h-full object-cover">
                  <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                    <div class="opacity-0 group-hover:opacity-100 flex gap-1">
                      <button type="button" class="btn-icon bg-white text-gray-700 hover:bg-gray-100" data-action="view" data-photo-id="${t.id}" title="Voir en grand">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                      </button>
                      <button type="button" class="btn-icon bg-red-500 text-white hover:bg-red-600" data-action="delete" data-photo-id="${t.id}" title="Supprimer">
                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
                ${t.caption?`<p class="text-xs text-gray-600 dark:text-gray-400 leading-snug">${t.caption}</p>`:""}
              </div>
            `).join("")}
          </div>
        `:`
          <div class="text-center py-6 text-gray-500 dark:text-gray-400 text-sm">
            Aucune photo ajoutée
          </div>
        `}
      </div>
      
      <input type="file" id="file-input" accept="image/*" style="display: none;">
    `,this.attachEventListeners()}attachEventListeners(){const t=this.querySelector("#add-from-camera"),o=this.querySelector("#add-from-gallery"),s=this.querySelector("#file-input");t?.addEventListener("click",()=>this.handleCameraCapture()),o?.addEventListener("click",()=>s.click()),s?.addEventListener("change",e=>this.handleFileSelect(e)),this.addEventListener("click",e=>{const i=e.target.closest("[data-action]");if(i){const d=i.dataset.action,l=i.dataset.photoId;d==="view"&&l?this.viewPhoto(l,e):d==="delete"&&l&&this.deletePhoto(l)}})}async handleCameraCapture(){try{const t=await I();await this.previewAndConfirmPhoto(t)}catch(t){if(console.error("Erreur capture caméra:",t),t instanceof Error&&t.message.includes("annulé"))return;alert("Impossible d'accéder à la caméra. Vérifiez les permissions.")}}async handleFileSelect(t){const o=t.target,s=o.files?.[0];if(s)try{const e=await M(s);await this.previewAndConfirmPhoto(e)}catch(e){console.error("Erreur compression image:",e),alert("Erreur lors du traitement de l'image.")}o.value=""}async previewAndConfirmPhoto(t){return new Promise((o,s)=>{const e=document.createElement("div");e.className="modal-overlay",e.innerHTML=`
        <div class="modal-content max-w-2xl">
          <div class="p-6">
            <div class="flex justify-between items-center mb-4">
              <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Prévisualisation de la photo</h3>
              <button type="button" class="btn-icon" id="close-preview">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
              </button>
            </div>
            
            <div class="mb-6">
              <img src="${t}" alt="Prévisualisation" class="w-full h-auto max-h-96 object-contain rounded-lg border border-gray-200 dark:border-gray-600">
            </div>
            
            <div class="mb-4">
              <label for="photo-caption" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Légende (optionnelle)
              </label>
              <input 
                type="text" 
                id="photo-caption" 
                class="input" 
                placeholder="Ajouter une description à cette photo..."
                maxlength="200"
              />
            </div>
            
            <div class="flex justify-end gap-3">
              <button type="button" class="btn-secondary" id="cancel-photo">
                ❌ Annuler
              </button>
              <button type="button" class="btn-primary" id="confirm-photo">
                ✅ Ajouter la photo
              </button>
            </div>
          </div>
        </div>
      `,document.body.appendChild(e);const a=()=>{document.body.removeChild(e),s(new Error("Annulé par l'utilisateur"))},i=async()=>{const m=e.querySelector("#photo-caption").value.trim();document.body.removeChild(e),await this.addPhoto(t,m),o()};e.querySelector("#close-preview")?.addEventListener("click",a),e.querySelector("#cancel-photo")?.addEventListener("click",a),e.querySelector("#confirm-photo")?.addEventListener("click",i),e.addEventListener("click",l=>{l.target===e&&a()});const d=l=>{l.key==="Escape"&&(a(),document.removeEventListener("keydown",d))};document.addEventListener("keydown",d),setTimeout(()=>{e.querySelector("#photo-caption")?.focus()},100)})}async addPhoto(t,o){const s={id:q(),dataURL:t,createdAt:Date.now(),caption:o||void 0};this.photos.push(s),this.render(),this.onPhotoAdd&&this.onPhotoAdd(s)}viewPhoto(t,o){if(o&&(o.stopPropagation(),o.preventDefault()),document.querySelector(".modal-overlay"))return;const s=this.photos.find(d=>d.id===t);if(!s)return;const e=document.createElement("div");e.className="modal-overlay",e.innerHTML=`
      <div class="modal-content max-w-4xl">
        <div class="p-4">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-semibold">Photo</h3>
            <button type="button" class="btn-icon" id="close-modal">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>
          <img src="${s.dataURL}" alt="Photo" class="w-full h-auto max-h-[70vh] object-contain rounded-lg">
          <div class="mt-4 text-sm text-gray-500 dark:text-gray-400">
            Ajoutée le ${new Date(s.createdAt).toLocaleString("fr-FR")}
          </div>
        </div>
      </div>
    `,document.body.appendChild(e);const a=()=>{document.body.removeChild(e)};e.querySelector("#close-modal")?.addEventListener("click",a),e.addEventListener("click",d=>{d.target===e&&a()});const i=d=>{d.key==="Escape"&&(a(),document.removeEventListener("keydown",i))};document.addEventListener("keydown",i)}async findTemporaryPhoto(t){const o=this.photos.find(s=>s.id===t);if(!o)return null;try{const{getTemporaryPhotos:s}=await b(async()=>{const{getTemporaryPhotos:a}=await import("./temp-photos-BVCntkeW.js");return{getTemporaryPhotos:a}},__vite__mapDeps([0,1,2,3]));return(await s()).find(a=>a.imageData===o.dataURL)||null}catch(s){return console.error("Erreur lors de la recherche de la photo temporaire:",s),null}}async deletePhoto(t){if(confirm("Êtes-vous sûr de vouloir supprimer cette photo ?")){this.photos=this.photos.filter(o=>o.id!==t),this.render(),this.onPhotoRemove&&this.onPhotoRemove(t);try{const o=await this.findTemporaryPhoto(t);if(o){const{deleteTemporaryPhoto:s}=await b(async()=>{const{deleteTemporaryPhoto:e}=await import("./temp-photos-BVCntkeW.js");return{deleteTemporaryPhoto:e}},__vite__mapDeps([0,1,2,3]));await s(o.id),console.log("Photo temporaire supprimée avec succès"),document.dispatchEvent(new CustomEvent("temp-photos-updated"))}}catch(o){console.error("Erreur lors de la suppression de la photo temporaire:",o)}}}}customElements.define("photo-gallery",O);class _ extends HTMLElement{constructor(){super(...arguments);c(this,"studentId","");c(this,"eventListener",null)}static get observedAttributes(){return["student-id"]}attributeChangedCallback(t,o,s){t==="student-id"&&s&&(this.studentId=s,this.setupEventListeners(),this.render())}connectedCallback(){this.studentId&&(this.setupEventListeners(),this.render())}disconnectedCallback(){this.eventListener&&g.off("skill-updated",this.eventListener)}setupEventListeners(){this.eventListener&&g.off("skill-updated",this.eventListener),this.eventListener=t=>{t.detail.studentId===this.studentId&&this.render()},g.on("skill-updated",this.eventListener)}getPeriodName(t){return{1:"Sept-Oct",2:"Nov-Déc",3:"Jan-Fév",4:"Mar-Avr",5:"Mai-Juin"}[t]||"Inconnue"}async render(){if(!this.studentId)return;const t=await v(this.studentId);if(!t)return;const o=await k("includeTransversal")??!1,s=f(o),e=L(t.skills),a=S(t.skills,t.meta.periode),i=s.map(d=>{const l=d.skills.map(p=>t.skills[p.id]).filter(Boolean),m=l.filter(p=>p.status==="A").length,u=l.filter(p=>p.status==="EC").length,$=l.filter(p=>p.status==="NA").length,h=l.length;return{name:d.name,color:d.color,acquired:m,inProgress:u,notAcquired:$,total:h,percentage:h>0?Math.round(m/h*100):0}});this.innerHTML=`
      <div class="card p-4 mb-6">
        <h2 class="text-lg font-semibold mb-4 flex items-center gap-2">
          <svg class="w-5 h-5 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
          </svg>
          Progression générale - Programmes 2025
        </h2>
        
        <div class="grid md:grid-cols-2 gap-6">
          <!-- Statistiques globales -->
          <div>
            <h3 class="font-medium mb-3">Vue d'ensemble</h3>
            <div class="space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-sm">Compétences acquises</span>
                <span class="font-semibold text-green-600">${e.acquired}/${e.total}</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-sm">En cours d'acquisition</span>
                <span class="font-semibold text-blue-600">${e.inProgress}</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-sm">Non acquises</span>
                <span class="font-semibold text-red-600">${e.notAcquired}</span>
              </div>
              <div class="mt-3 pt-3 border-t space-y-3">
                <div>
                  <div class="flex justify-between items-center">
                    <span class="font-medium">Progression globale</span>
                    <span class="font-bold text-lg ${e.percentage>=80?"text-green-600":e.percentage>=60?"text-blue-600":e.percentage>=40?"text-yellow-600":"text-red-600"}">${e.percentage}%</span>
                  </div>
                  <div class="progress-bar mt-2">
                    <div class="progress-fill ${e.percentage>=80?"bg-green-500":e.percentage>=60?"bg-blue-500":e.percentage>=40?"bg-yellow-500":"bg-red-500"}" style="width: ${e.percentage}%"></div>
                  </div>
                </div>
                <div>
                  <div class="flex justify-between items-center">
                    <span class="font-medium">Période ${t.meta.periode} (${this.getPeriodName(t.meta.periode)})</span>
                    <span class="font-bold text-lg ${a.percentage>=80?"text-primary-600":a.percentage>=60?"text-blue-600":a.percentage>=40?"text-yellow-600":"text-orange-600"}">${a.percentage}%</span>
                  </div>
                  <div class="progress-bar mt-2">
                    <div class="progress-fill ${a.percentage>=80?"bg-primary-500":a.percentage>=60?"bg-blue-500":a.percentage>=40?"bg-yellow-500":"bg-orange-500"}" style="width: ${a.percentage}%"></div>
                  </div>
                  <div class="text-xs text-gray-500 mt-1">
                    ${a.acquired}/${a.total} compétences acquises cette période
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Répartition par domaine -->
          <div>
            <h3 class="font-medium mb-3">Répartition par domaine</h3>
            <div class="space-y-2">
              ${i.map(d=>`
                <div class="flex items-center justify-between text-sm">
                  <div class="flex items-center gap-2">
                    <div class="w-3 h-3 rounded ${d.color}"></div>
                    <span class="truncate">${d.name.split(" ").slice(0,3).join(" ")}...</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <span class="font-medium">${d.acquired}/${d.total}</span>
                    <span class="text-xs px-1.5 py-0.5 rounded ${d.percentage>=80?"bg-green-100 text-green-700":d.percentage>=60?"bg-blue-100 text-blue-700":d.percentage>=40?"bg-yellow-100 text-yellow-700":"bg-red-100 text-red-700"}">${d.percentage}%</span>
                  </div>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      </div>
    `}}customElements.define("stats-summary",_);class F extends HTMLElement{constructor(){super(...arguments);c(this,"studentId","");c(this,"student",null);c(this,"carnet",null)}static get observedAttributes(){return["student-id"]}attributeChangedCallback(t,o,s){t==="student-id"&&s&&(this.studentId=s,this.loadData())}connectedCallback(){this.studentId&&this.loadData()}async loadData(){try{if(this.student=await x(this.studentId),!this.student){this.renderError("Élève introuvable");return}this.carnet=await v(this.studentId),this.carnet||(this.carnet=await C(this.studentId,this.student)),this.render()}catch(t){console.error("Erreur lors du chargement:",t),this.renderError("Erreur lors du chargement des données")}}renderError(t){this.innerHTML=`
      <div class="min-h-screen flex items-center justify-center">
        <div class="text-center">
          <svg class="w-16 h-16 mx-auto text-red-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/>
          </svg>
          <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">${t}</h2>
          <button class="btn-primary" onclick="history.back()">Retour</button>
        </div>
      </div>
    `}async render(){if(!this.student||!this.carnet)return;const t=await k("includeTransversal")??!1,o=f(t),s=this.sortDomainsByCustomOrder(o);this.innerHTML=`
      <div class="min-h-screen flex flex-col">
        <!-- Navigation -->
        <!-- En-tête avec informations élève -->
        <header class="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 pt-safe-top">
          <!-- Barre de navigation simple -->
          <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-700">
            <button id="back-btn" class="btn-icon" title="Retour à la liste">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
              </svg>
            </button>
          </div>

          <!-- Informations élève -->
          <div class="px-4 py-6">
            <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden bg-gray-100 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                ${this.student.avatar?`
                  <img src="${this.student.avatar}" alt="Avatar" class="w-full h-full object-cover" />
                `:`
                  <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                  </svg>
                `}
              </div>
              <div class="flex-1 min-w-0">
                <h1 class="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100 mb-1">
                  ${this.student.prenom} ${this.student.nom}
                </h1>
                <p class="text-base text-gray-600 dark:text-gray-400 mb-2">
                  Carnet de suivi Maternelle - Programmes 2025
                </p>
                ${this.carnet?`
                  <div class="flex flex-wrap gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <span> ${this.carnet.meta.annee}-${parseInt(this.carnet.meta.annee)+1}</span>
                    <span> ${this.carnet.meta.enseignant}</span>
                    <span> Période ${this.carnet.meta.periode}</span>
                  </div>
                `:""}
              </div>
            </div>

            <!-- Boutons d'action -->
            <div class="mt-6 flex flex-wrap gap-2">
              <button id="edit-student-btn" class="btn-secondary flex-1 sm:flex-none" title="Modifier l'élève">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
                Élève
              </button>
              <button id="edit-meta-btn" class="btn-secondary flex-1 sm:flex-none" title="Modifier les informations du carnet">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                </svg>
                Carnet
              </button>
              <button id="synthese-btn" class="btn-secondary flex-1 sm:flex-none" title="Synthèse générale">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                Synthèse
              </button>
              <button id="print-btn" class="btn-primary flex-1 sm:flex-none" title="Imprimer le carnet">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
                </svg>
                Imprimer
              </button>
            </div>
          </div>
        </header>

        <!-- Contenu principal -->
        <main class="flex-1 container mx-auto px-4 py-6">
          <div class="mb-6">
            <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100">Évaluation des compétences</h2>
          </div>

          <!-- Statistiques globales -->
          <stats-summary student-id="${this.studentId}"></stats-summary>

          <!-- Domaines de compétences -->
          <section class="space-y-4" aria-label="Domaines">
            <div class="flex items-center justify-between mb-6">
              <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100">
                📚 Domaines de compétences
              </h2>
              <div class="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                </svg>
                Glisser-déposer pour réorganiser
              </div>
            </div>
            
            <div id="domains-container" class="space-y-3">
              ${s.length>0?s.map((e,a)=>{const i=w(e.id,this.carnet.skills);return`
                  <div class="domain-item" draggable="true" data-domain-id="${e.id}" data-index="${a}">
                    <domain-card 
                      student-id="${this.studentId}"
                      data-domain-id="${e.id}" 
                      data-name="${e.name}" 
                      data-color="${e.color}" 
                      data-percentage="${i.percentage}" 
                      data-acquired="${i.acquired}" 
                      data-total="${i.total}">
                    </domain-card>
                  </div>
                `}).join(""):`
                <div class="text-center py-8">
                  <p class="text-gray-500">Aucun domaine trouvé. Vérifiez la configuration.</p>
                  <p class="text-sm text-gray-400 mt-2">Domaines disponibles: ${s.length}</p>
                </div>
              `}
            </div>
          </section>
        </main>

        <!-- Modales -->
        <student-modal></student-modal>
        <meta-modal></meta-modal>
        <synthese-modal></synthese-modal>
      </div>
    `,this.attachEvents()}attachEvents(){this.querySelector("#back-btn")?.addEventListener("click",()=>{j.goToStudentsList()}),this.querySelector("#edit-student-btn")?.addEventListener("click",()=>{this.editStudent()}),this.querySelector("#edit-meta-btn")?.addEventListener("click",()=>{this.editMeta()}),this.querySelector("#print-btn")?.addEventListener("click",async()=>{await A(this.studentId)}),this.querySelector("#synthese-btn")?.addEventListener("click",()=>{this.showSynthese()}),this.setupDragAndDrop()}editStudent(){this.querySelector("student-modal").openForEdit(this.studentId,o=>{console.log("Élève modifié:",o),this.student=o,this.render()},()=>{console.log("Modification annulée")})}editMeta(){this.querySelector("meta-modal").openForEdit(this.studentId,async o=>{console.log("Métadonnées modifiées:",o),this.carnet&&(this.carnet.meta=o),await this.loadData()},()=>{console.log("Modification annulée")})}async exportStudent(){try{console.log("Export élève",this.studentId)}catch(t){console.error("Erreur export:",t),alert("Erreur lors de l'export")}}showSynthese(){this.querySelector("synthese-modal").openForEdit(this.studentId,o=>{console.log("Synthèse modifiée:",o),this.loadData()},()=>{console.log("Modification synthèse annulée")})}setupDragAndDrop(){const t=this.querySelector("#domains-container");if(!t)return;let o=null;t.addEventListener("dragstart",s=>{const e=s,i=s.target.closest(".domain-item");i&&(o=i,i.dataset.index=i.dataset.index||"0",i.classList.add("opacity-50","scale-95"),e.dataTransfer&&(e.dataTransfer.effectAllowed="move",e.dataTransfer.setData("text/html",i.outerHTML)))}),t.addEventListener("dragend",s=>{const a=s.target.closest(".domain-item");a&&a.classList.remove("opacity-50","scale-95"),o=null,t.querySelectorAll(".drop-indicator").forEach(i=>{i.remove()})}),t.addEventListener("dragover",s=>{const e=s;s.preventDefault(),e.dataTransfer&&(e.dataTransfer.dropEffect="move");const i=s.target.closest(".domain-item");if(i&&i!==o){t.querySelectorAll(".drop-indicator").forEach(u=>{u.remove()});const d=document.createElement("div");d.className="drop-indicator h-1 bg-blue-500 rounded-full mx-4 transition-all duration-200";const l=i.getBoundingClientRect(),m=l.top+l.height/2;e.clientY<m?i.parentNode?.insertBefore(d,i):i.parentNode?.insertBefore(d,i.nextSibling)}}),t.addEventListener("drop",s=>{const e=s;s.preventDefault();const i=s.target.closest(".domain-item");if(i&&o&&i!==o){const d=i.getBoundingClientRect(),l=d.top+d.height/2;e.clientY<l?i.parentNode?.insertBefore(o,i):i.parentNode?.insertBefore(o,i.nextSibling),this.saveDomainOrder(),this.showReorderSuccess()}t.querySelectorAll(".drop-indicator").forEach(d=>{d.remove()})}),t.querySelectorAll(".domain-item").forEach(s=>{const e=s;e.style.cursor="grab",e.addEventListener("dragstart",()=>{e.style.cursor="grabbing"}),e.addEventListener("dragend",()=>{e.style.cursor="grab"})})}saveDomainOrder(){const t=this.querySelector("#domains-container");if(!t)return;const o=t.querySelectorAll(".domain-item"),s=Array.from(o).map((e,a)=>({domainId:e.dataset.domainId,order:a}));localStorage.setItem(`domain-order-${this.studentId}`,JSON.stringify(s)),console.log("Nouvel ordre des domaines sauvegardé:",s)}loadDomainOrder(){try{const t=localStorage.getItem(`domain-order-${this.studentId}`);if(t)return JSON.parse(t).map(s=>s.domainId)}catch(t){console.error("Erreur chargement ordre domaines:",t)}return[]}showReorderSuccess(){const t=document.createElement("div");t.className="fixed top-4 right-4 bg-green-600 text-white px-4 py-2 rounded-lg shadow-lg z-50 flex items-center",t.innerHTML=`
      <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
      </svg>
      Ordre des domaines mis à jour
    `,document.body.appendChild(t),setTimeout(()=>{t.remove()},2e3)}sortDomainsByCustomOrder(t){const o=this.loadDomainOrder();if(o.length===0)return t;const s=[],e=[...t];for(const a of o){const i=e.findIndex(d=>d.id===a);i!==-1&&s.push(e.splice(i,1)[0])}return s.push(...e),s}}customElements.define("student-detail",F);export{F as StudentDetail};
