const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/temp-photos-BVCntkeW.js","assets/main-CA8ihvBi.js","assets/main-uwlzZ6gw.css","assets/db-BumgrVF8.js"])))=>i.map(i=>d[i]);
var v=Object.defineProperty;var m=(n,a,e)=>a in n?v(n,a,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[a]=e;var i=(n,a,e)=>m(n,typeof a!="symbol"?a+"":a,e);import{_ as b}from"./main-CA8ihvBi.js";import{g as f}from"./students-repo-DiS-lCzz.js";import{getTemporaryPhotos as x}from"./temp-photos-BVCntkeW.js";import{router as l}from"./router-CANAWL_W.js";import"./db-BumgrVF8.js";class y extends HTMLElement{constructor(){super(...arguments);i(this,"students",[]);i(this,"stream",null);i(this,"video",null);i(this,"capturedPhoto",null);i(this,"fileInput",null);i(this,"canvas",null);i(this,"selectedStudentId",null);i(this,"pendingTempPhotosCount",0)}connectedCallback(){this.loadStudents()}disconnectedCallback(){this.stopCamera()}async loadStudents(){try{this.students=await f(),this.render()}catch(e){console.error("Erreur chargement élèves:",e),this.renderError()}}stopCamera(){this.stream&&(this.stream.getTracks().forEach(e=>e.stop()),this.stream=null)}showError(e){console.error(e);const t=this.querySelector("#error-message");t&&(t.textContent=e,t.classList.remove("hidden"),setTimeout(()=>{t.classList.add("hidden")},5e3))}showSuccess(){const e=this.querySelector("#success-message");e&&(e.classList.remove("hidden"),setTimeout(()=>{e.classList.add("hidden")},3e3))}async render(){try{const e=await x();this.pendingTempPhotosCount=e.length;const t=this.pendingTempPhotosCount>0;this.capturedPhoto?this.innerHTML=this.renderPhotoReview():this.selectedStudentId?(this.innerHTML=this.renderCameraView(),this.initializeCamera().catch(console.error)):this.innerHTML=`
          <div id="student-selection-view" class="bg-white min-h-screen">
            <div class="max-w-5xl mx-auto min-h-screen flex flex-col">
              <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 pt-safe-top">
                <div class="px-4 py-4">
                  <div class="flex items-center">
                    <button id="back-btn" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                      </svg>
                    </button>
                    <h1 class="text-xl font-semibold text-gray-900 dark:text-gray-100 mx-auto">
                      Mode élève
                    </h1>
                    <div class="flex items-center gap-2">
                      <div class="relative opacity-50 cursor-not-allowed" title="Photos en attente">
                        <div class="btn-icon">
                          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                          </svg>
                          <span class="temp-photos-count absolute -top-2 -right-2 px-2 py-1 bg-gray-500 text-white text-xs rounded-full ${t?"":"hidden"}">
                            ${this.pendingTempPhotosCount}
                          </span>
                        </div>
                      </div>
                  </div>
                </div>
              </header>
              <main class="flex-1 px-4 py-6">
                ${this.renderStudentSelection()}
              </main>
            </div>
          </div>`,this.setupEventListeners()}catch(e){console.error("Erreur lors du rendu:",e),this.renderError()}}renderError(){this.innerHTML=`
      <div class="p-4 text-red-600">
        <p>Erreur lors du chargement des données. Veuillez réessayer plus tard.</p>
      </div>`}renderPhotoReview(){if(!this.capturedPhoto)return"";const e=this.students.find(r=>r.id===this.selectedStudentId);return`
      <div class="bg-white dark:bg-gray-900 min-h-screen">
        <div class="max-w-5xl mx-auto min-h-screen flex flex-col">
          <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 pt-safe-top">
            <div class="px-4 py-4">
              <div class="flex items-center">
                <button id="back-btn" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                  </svg>
                </button>
                <h1 class="text-xl font-semibold text-gray-900 dark:text-gray-100 mx-auto flex items-center gap-2">
                  Aperçu de la photo
                </h1>
                <div class="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400">
                  <span class="text-sm text-gray-500 dark:text-gray-400">${e?`${e.prenom} ${e.nom}`:"Élève"}</span>
                </div>
              </div>
            </div>
          </header>
          <main class="flex-1 px-4 py-6 space-y-6">
            <div class="rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 flex items-center justify-center aspect-[3/4] sm:aspect-[4/3] overflow-hidden">
              <img src="${this.capturedPhoto}" alt="Aperçu de la photo" class="h-full w-full object-contain" />
            </div>
            <div class="flex flex-col gap-3 sm:flex-row sm:gap-4 sm:justify-center">
              <button id="retake-btn" class="px-6 py-2 rounded-full bg-white dark:bg-gray-800 text-sm font-medium text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-700 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                Reprendre
              </button>
              <button id="save-btn" class="px-6 py-2 rounded-full bg-green-500 text-sm font-medium text-white shadow-sm hover:bg-green-600 transition-colors flex items-center justify-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
                Enregistrer
              </button>
            </div>
          </main>
        </div>
      </div>`}renderStudentSelection(){return this.students.length===0?`
        <div class="p-4 text-center">
          <p class="text-red-500">Aucun élève trouvé. Veuillez réessayer plus tard.</p>
          <button id="retry-btn" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
            Réessayer
          </button>
        </div>`:`
      <div class="space-y-4">
        <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Sélectionnez un élève</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
          ${this.students.map(e=>{const t=e.photo||e.avatar||"",r=`${e.prenom.charAt(0)}${e.nom.charAt(0)}`;return`
              <div class="group relative cursor-pointer" data-student-id="${e.id}" id="student-${e.id}">
                <input type="radio" id="student-radio-${e.id}" name="student-selection" class="sr-only" value="${e.id}">
                <label for="student-radio-${e.id}" class="block cursor-pointer">
                <div class="relative w-full pb-[135%] overflow-hidden rounded-3xl shadow-md border border-transparent transition-all duration-200 group-hover:shadow-xl group-hover:border-blue-200 dark:group-hover:border-blue-500" role="button" tabindex="0">
                  ${t?`
                    <img src="${t}" alt="Portrait de ${e.prenom} ${e.nom}" class="absolute inset-0 h-full w-full object-cover" />
                  `:`
                    <div class="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-blue-200 via-indigo-200 to-purple-200 dark:from-blue-900 dark:via-indigo-900 dark:to-purple-900 text-white">
                      <span class="text-3xl font-semibold">${r}</span>
                    </div>
                  `}
                  <div class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent px-3 py-2">
                    <p class="text-sm font-medium text-white leading-tight">${e.prenom}</p>
                    <p class="text-[11px] uppercase tracking-wide text-white/80">${e.nom}</p>
                  </div>
                  <div class="absolute inset-0 rounded-3xl ring-0 ring-blue-400/0 group-hover:ring-4 group-hover:ring-blue-400/40 dark:group-hover:ring-blue-500/40 transition"></div>
                </div>
                </label>
              </div>
            `}).join("")}
        </div>
      </div>`}renderCameraView(){const e=this.students.find(r=>r.id===this.selectedStudentId),t=e?`${e.prenom} ${e.nom}`:"Élève sélectionné";return`
      <div class="bg-white dark:bg-gray-900 min-h-screen">
        <div class="max-w-5xl mx-auto min-h-screen flex flex-col">
          <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 pt-safe-top">
            <div class="px-4 py-4">
              <div class="flex items-center">
                <button id="back-btn" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                  </svg>
                </button>
                <h1 class="text-xl font-semibold text-gray-900 dark:text-gray-100 mx-auto">
                  Prendre une photo
                </h1>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                  ${t}
                </div>
              </div>
            </div>
          </header>
          <main class="flex-1 px-4 py-6 space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-3 text-sm text-gray-600 dark:text-gray-300">
              <p class="font-medium text-gray-900 dark:text-white">Élève sélectionné : ${t}</p>
              <button id="back-to-students" class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 dark:text-blue-300 dark:hover:text-blue-200 transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h8m-8 6h16" />
                </svg>
                Changer d'élève
              </button>
            </div>
            <div class="relative rounded-2xl bg-black overflow-hidden aspect-[3/4] sm:aspect-[4/3]">
              <video 
                id="camera-preview" 
                class="w-full h-full object-cover"
                autoplay
                muted
                playsinline
                webkit-playsinline
                x-webkit-airplay="allow"
                x5-video-player-type="h5"
                x5-video-player-fullscreen="true"
                x5-video-orientation="portrait"
              ></video>
              <div id="camera-error" class="absolute inset-0 flex items-center justify-center bg-black/60 text-white text-center px-6 py-4 hidden">
                <p>La caméra n'est pas disponible. Vérifiez les permissions ou utilisez le bouton ci-dessous pour importer une photo.</p>
              </div>
              <div id="camera-loading" class="absolute inset-0 flex items-center justify-center bg-black/30 hidden">
                <div class="animate-spin rounded-full h-10 w-10 border-2 border-white/70 border-t-transparent"></div>
              </div>
            </div>
            <div class="flex flex-col items-center gap-3 sm:flex-row sm:justify-center sm:gap-6">
              <button id="capture-btn" class="px-6 py-3 rounded-full bg-blue-600 text-white font-semibold shadow-sm hover:bg-blue-700 transition-colors">
                Prendre la photo
              </button>
              <button id="upload-btn" class="px-6 py-3 rounded-full bg-white text-blue-600 font-semibold border border-blue-200 shadow-sm hover:bg-blue-50 transition-colors">
                Importer
              </button>
            </div>
          </main>
          <div id="error-message" class="fixed bottom-4 left-4 right-4 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg hidden"></div>
          <div id="success-message" class="fixed bottom-4 left-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg hidden">
            Photo enregistrée avec succès !
          </div>
        </div>
      </div>`}capturePhoto(){if(!this.video){console.log("La caméra n'est pas prête. Veuillez réessayer.");return}this.canvas||(this.canvas=document.createElement("canvas"));const e=this.video.videoWidth||this.video.clientWidth,t=this.video.videoHeight||this.video.clientHeight;if(!e||!t){console.log("La caméra n'est pas encore prête. Patientez un instant puis réessayez.");return}this.canvas.width=e,this.canvas.height=t;const r=this.canvas.getContext("2d");r&&(r.drawImage(this.video,0,0,this.canvas.width,this.canvas.height),this.capturedPhoto=this.canvas.toDataURL("image/jpeg",.9),this.render())}async savePhoto(){if(console.group("savePhoto"),console.log("Début de la sauvegarde de la photo..."),!this.capturedPhoto){console.error("Aucune photo capturée"),this.showError("Aucune photo à enregistrer.");return}if(!this.selectedStudentId){console.error("Aucun élève sélectionné"),this.showError("Aucun élève sélectionné.");return}try{console.log("Chargement du module temp-photos...");const e=await b(()=>import("./temp-photos-BVCntkeW.js"),__vite__mapDeps([0,1,2,3]));if(console.log("Module temp-photos chargé:",Object.keys(e)),typeof e.saveTemporaryPhoto!="function")throw new Error("La fonction saveTemporaryPhoto n'existe pas dans le module");console.log("Sauvegarde de la photo pour l'élève:",this.selectedStudentId),console.log("Taille de la photo:",this.capturedPhoto.length,"caractères");const t=await e.saveTemporaryPhoto({studentId:this.selectedStudentId,imageData:this.capturedPhoto,timestamp:Date.now()});console.log("Photo sauvegardée avec ID:",t);const r=await e.getTemporaryPhoto(t);if(console.log("Photo récupérée après sauvegarde:",r?"succès":"échec"),!r)throw new Error("La photo n'a pas pu être récupérée après la sauvegarde");const s=await e.getTemporaryPhotos();console.log("Nombre total de photos temporaires:",s.length),this.showSuccess(),console.log("Déclenchement de l'événement temp-photos-updated");const o=new CustomEvent("temp-photos-updated",{detail:{count:s.length}});document.dispatchEvent(o),this.capturedPhoto=null,this.render(),console.log("Photo sauvegardée avec succès, prêt pour une nouvelle capture")}catch(e){console.error("Erreur lors de la sauvegarde de la photo:",e);const t=e instanceof Error?e.message:"Impossible de sauvegarder la photo";this.showError(`Erreur: ${t}`)}finally{console.groupEnd()}}setupFileInput(){return this.fileInput&&(document.body.removeChild(this.fileInput),this.fileInput=null),this.fileInput=document.createElement("input"),this.fileInput.type="file",this.fileInput.accept="image/*",this.fileInput.style.display="none",document.body.appendChild(this.fileInput),this.fileInput.addEventListener("change",e=>{const t=e.target;if(t.files&&t.files[0]){const r=t.files[0],s=new FileReader;s.onload=o=>{o.target?.result&&(this.capturedPhoto=o.target.result,this.render())},s.readAsDataURL(r)}}),this.fileInput}async initializeCamera(){try{if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)throw new Error("L'API de la caméra n'est pas disponible sur cet appareil");this.stream&&this.stream.getTracks().forEach(t=>t.stop());const e={video:{facingMode:{ideal:"environment"},width:{ideal:1280,max:1920},height:{ideal:720,max:1080},frameRate:{ideal:30}},audio:!1};if(this.stream=await navigator.mediaDevices.getUserMedia(e),this.video=this.querySelector("#camera-preview"),this.video){this.video.srcObject=this.stream,this.video.setAttribute("playsinline","true"),this.video.setAttribute("autoplay","true"),this.video.setAttribute("muted","true"),this.video.setAttribute("webkit-playsinline","true");const t=this.querySelector("#camera-loading");t&&t.classList.remove("hidden"),await new Promise(r=>{const s=()=>{this.video&&this.video.removeEventListener("playing",s),t&&t.classList.add("hidden"),r()};this.video&&(this.video.addEventListener("playing",s),this.video.play().catch(o=>{console.log("Erreur lecture vidéo (peut être normal selon les permissions):",o),t&&t.classList.add("hidden")}))})}}catch(e){console.error("Erreur initialisation caméra:",e)}}setupEventListeners(){this.querySelectorAll("[data-student-id]").forEach(d=>{d.addEventListener("click",g=>{const p=g.currentTarget.getAttribute("data-student-id");p&&(this.selectedStudentId=p,this.render())})});const t=this.querySelector("#back-to-students");t&&t.addEventListener("click",()=>{this.selectedStudentId=null,this.render()});const r=this.querySelector("#retry-btn");r&&r.addEventListener("click",()=>this.loadStudents());const s=this.querySelector("#capture-btn");s&&s.addEventListener("click",()=>this.capturePhoto());const o=this.querySelector("#upload-btn");o&&o.addEventListener("click",()=>{const d=this.setupFileInput();d&&d.click()});const c=this.querySelector("#retake-btn");c&&c.addEventListener("click",()=>{this.capturedPhoto=null,this.render()});const u=this.querySelector("#save-btn");u&&u.addEventListener("click",()=>this.savePhoto());const h=this.querySelector("#back-btn");h&&h.addEventListener("click",()=>{if(this.stopCamera(),this.capturedPhoto){this.capturedPhoto=null,this.render();return}if(this.selectedStudentId){this.selectedStudentId=null,this.render();return}l&&typeof l.navigateTo=="function"&&l.navigateTo({name:"home"})})}}customElements.get("student-camera")||customElements.define("student-camera",y);export{y as StudentCamera};
